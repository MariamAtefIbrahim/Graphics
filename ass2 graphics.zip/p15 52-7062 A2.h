#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <glut.h>
#include <string.h>
#include <iostream>


#define GLUT_KEY_ESCAPE 27
#define DEG2RAD(a) (a * 0.0174532925)

class Vector3f {
public:
	float x, y, z;

	Vector3f(float _x = 0.0f, float _y = 0.0f, float _z = 0.0f) {
		x = _x;
		y = _y;
		z = _z;
	}

	Vector3f operator+(Vector3f& v) {
		return Vector3f(x + v.x, y + v.y, z + v.z);
	}

	Vector3f operator-(Vector3f& v) {
		return Vector3f(x - v.x, y - v.y, z - v.z);
	}

	Vector3f operator*(float n) {
		return Vector3f(x * n, y * n, z * n);
	}

	Vector3f operator/(float n) {
		return Vector3f(x / n, y / n, z / n);
	}

	Vector3f unit() {
		return *this / sqrt(x * x + y * y + z * z);
	}

	Vector3f cross(Vector3f v) {
		return Vector3f(y * v.z - z * v.y, z * v.x - x * v.z, x * v.y - y * v.x);
	}
};

class Camera {
public:
	Vector3f eye, center, up;

	Camera(float eyeX = 1.0f, float eyeY = 1.0f, float eyeZ = 1.0f, float centerX = 0.0f, float centerY = 0.0f, float centerZ = 0.0f, float upX = 0.0f, float upY = 1.0f, float upZ = 0.0f) {
		eye = Vector3f(eyeX, eyeY, eyeZ);
		center = Vector3f(centerX, centerY, centerZ);
		up = Vector3f(upX, upY, upZ);
	}

	void moveX(float d) {
		Vector3f right = up.cross(center - eye).unit();
		eye = eye + right * d;
		center = center + right * d;
	}

	void moveY(float d) {
		eye = eye + up.unit() * d;
		center = center + up.unit() * d;
	}

	void moveZ(float d) {
		Vector3f view = (center - eye).unit();
		eye = eye + view * d;
		center = center + view * d;
	}

	void rotateX(float a) {
		Vector3f view = (center - eye).unit();
		Vector3f right = up.cross(view).unit();
		view = view * cos(DEG2RAD(a)) + up * sin(DEG2RAD(a));
		up = view.cross(right);
		center = eye + view;
	}

	void rotateY(float a) {
		Vector3f view = (center - eye).unit();
		Vector3f right = up.cross(view).unit();
		view = view * cos(DEG2RAD(a)) + right * sin(DEG2RAD(a));
		right = view.cross(up);
		center = eye + view;
	}

	void look() {
		gluLookAt(
			eye.x, eye.y, eye.z,
			center.x, center.y, center.z,
			up.x, up.y, up.z
		);
	}
};

Camera camera;

float playerX = 0.0f;
float playerZ = 0.0f;
float wallScale = 2.0f;
float rotationAngle = 0.0f;
float sphereRotationAngle = 0.0f;
float candyShopX = 1.5f; 
float candyShopZ = -1.8f;
int remainingTime = 100; 
int win = 0; 

bool animateBench = false;
bool animateDesk = false;
bool animateFerrisWheel = false;
bool animateSeesaw = false;
bool animateSphere = false;

float benchAnimationParameter = 0.0f;
float deskAnimationParameter = 0.0f;
float chairAnimationParameter = 0.0f;
float seesawAnimationParameter = 0.0f;
float ferrisWheelRotationAngle = 0.0f;
float candyShopBuildingScale = 1.0f;

float candyShopDoorScale = 1.0f;
float animationParameter = 0.0f;

void animateObjects() {
	candyShopBuildingScale = 1.0 + 0.1 * sin(animationParameter * 3.14);
	candyShopDoorScale = 1.0 + 0.1 * sin(animationParameter * 3.14);
	if (animateBench) {
		benchAnimationParameter += 0.05f;
		if (benchAnimationParameter > 1.0f) {
			benchAnimationParameter -= 1.0f;
		}
	}

	if (animateDesk) {
		deskAnimationParameter += 0.05f;
		if (deskAnimationParameter > 1.0f) {
			deskAnimationParameter -= 1.0f;
		}
	}

	if (animateSeesaw) {
		seesawAnimationParameter += 1.0f;
		if (seesawAnimationParameter > 45.0f) {
			seesawAnimationParameter = -45.0f;
		}
	}

	if (animateSphere) {
		sphereRotationAngle += 2.0f;
		if (sphereRotationAngle > 360.0f) {
			sphereRotationAngle -= 360.0f;
		}
	}
	if (animateFerrisWheel) {
		ferrisWheelRotationAngle += 2.0f;
		if (ferrisWheelRotationAngle > 360.0f) {
			ferrisWheelRotationAngle -= 360.0f;
		}
	}
	animationParameter += 0.05;
	glutPostRedisplay();
}

float wallColor1[3] = { 0.5, 0.5, 0.5 };  // Initial color
float wallColor2[3] = { 0.8, 0.8, 0.8 };  // Another color
bool changeColor = false;  // Flag to track color change

void Timer(int value) {
	if (remainingTime > 0) {
		remainingTime--;
	}
	else {
		win = -1; // Game is lost
	}
	changeColor = true;
	glutPostRedisplay(); // Trigger redrawing
	glutTimerFunc(1000, Timer, 0); 
	
}


void drawWall(double thickness) {
	// Check if it's time to change colors
	if (changeColor) {
		// Swap colors
		float tempColor[3];
		memcpy(tempColor, wallColor1, sizeof(wallColor1));
		memcpy(wallColor1, wallColor2, sizeof(wallColor2));
		memcpy(wallColor2, tempColor, sizeof(tempColor));

		// Reset the flag
		changeColor = false;
	}

	glColor3fv(wallColor1);
	glPushMatrix();
	glTranslated(0.5, 0.5 * thickness, 0.5);
	glScaled(2.0, thickness, 2.0);
	glutSolidCube(1);
	glPopMatrix();

	// Set the color for the window frame
	glColor3f(1, 0.8, 0.8); // Adjust the color of the window frame

	// Draw the window frame
	glPushMatrix();
	glTranslated(0.5, 0.8, 0);
	glScaled(2.0, 0.1, 0.01); 
	glutSolidCube(1);
	glPopMatrix();;

}


void drawBench() {
	// Bench seat (a long, thin cube)
	glColor3f(0.4, 0.2, 0.1); // Brown color for the seat
	glPushMatrix();
	glTranslated(0, 0.1 + 0.05 * sin(benchAnimationParameter * 3.14), 0);
	glScaled(0.15, 0.02, 0.05);
	glutSolidCube(1);
	glPopMatrix();

	// Leg 1 of the bench (a tall, thin cube)
	glColor3f(0.4, 0.2, 0.1); // Same color as the seat
	glPushMatrix();
	glTranslated(0.07, 0, 0.02); // Position one leg
	glScaled(0.01, 0.2, 0.01); // Define the leg size
	glutSolidCube(1);
	glPopMatrix();

	// Leg 2 of the bench (a tall, thin cube)
	glColor3f(0.4, 0.2, 0.1); // Same color as the seat
	glPushMatrix();
	glTranslated(-0.07, 0, 0.02); // Position another leg
	glScaled(0.01, 0.2, 0.01); // Define the leg size
	glutSolidCube(1);
	glPopMatrix();

	// Leg 3 of the bench (a tall, thin cube)
	glColor3f(0.4, 0.2, 0.1); // Same color as the seat
	glPushMatrix();
	glTranslated(0.07, 0, -0.02); // Position another leg
	glScaled(0.01, 0.2, 0.01); // Define the leg size
	glutSolidCube(1);
	glPopMatrix();

	// Leg 4 of the bench (a tall, thin cube)
	glColor3f(0.4, 0.2, 0.1); // Same color as the seat
	glPushMatrix();
	glTranslated(-0.07, 0, -0.02); // Position another leg
	glScaled(0.01, 0.2, 0.01); // Define the leg size
	glutSolidCube(1);
	glPopMatrix();
}

void drawDesk() {
	// Base cube with scaling animation
	glColor3f(0.6, 0.3, 0.1);
	glPushMatrix();
	glTranslated(0, 0, 1);
	glScaled(0.2 * (1.0 + 0.1 * sin(deskAnimationParameter * 3.14)), 0.05, 0.2 * (1.0 + 0.1 * sin(deskAnimationParameter * 3.14)));
	glutSolidCube(1);
	glPopMatrix();

	// Upper cube with scaling animation
	glColor3f(0.7, 0.7, 0.7);
	glPushMatrix();
	glTranslated(0, 0.05 * (1.0 + 0.1 * sin(deskAnimationParameter * 3.14)), 1);
	glScaled(0.15 * (1.0 + 0.1 * sin(deskAnimationParameter * 3.14)), 0.3, 0.15 * (1.0 + 0.1 * sin(deskAnimationParameter * 3.14)));
	glutSolidCube(1);
	glPopMatrix();

	// Additional cube with scaling animation
	glColor3f(0.7, 0.7, 0.7);
	glPushMatrix();
	glTranslated(0, 0.2 * (1.0 + 0.1 * sin(deskAnimationParameter * 3.14)), 0.03);
	glScaled(0.01 * (1.0 + 0.1 * sin(deskAnimationParameter * 3.14)), 0.04, 0.01 * (1.0 + 0.1 * sin(deskAnimationParameter * 3.14)));
	glutSolidCube(1);
	glPopMatrix();
}

void drawChair() {
	// Seat of the chair (a cube)
	glColor3f(0.4, 0.2, 0.1); // Brown color for the seat
	glPushMatrix();
	glTranslated(0, 0.15, 0);
	glScaled(0.1, 0.03, 0.1);
	glutSolidCube(1);
	glPopMatrix();

	// Backrest of the chair (a tall, narrow cube)
	glColor3f(0.4, 0.2, 0.1); // Same color as the seat
	glPushMatrix();
	glTranslated(0, 0.3, -0.05); // Position the backrest behind the seat
	glScaled(0.08, 0.2, 0.02); // Define the backrest size
	glutSolidCube(1);
	glPopMatrix();

	// Leg 1 of the chair (a thin, tall cube)
	glColor3f(0.4, 0.2, 0.1); // Same color as the seat
	glPushMatrix();
	glTranslated(0.05, 0, 0.05); // Position one leg
	glScaled(0.02, 0.3, 0.02); // Define the leg size
	glutSolidCube(1);
	glPopMatrix();

	// Leg 2 of the chair (a thin, tall cube)
	glColor3f(0.4, 0.2, 0.1); // Same color as the seat
	glPushMatrix();
	glTranslated(-0.05, 0, 0.05); // Position another leg
	glScaled(0.02, 0.3, 0.02); // Define the leg size
	glutSolidCube(1);
	glPopMatrix();

	// Leg 3 of the chair (a thin, tall cube)
	glColor3f(0.4, 0.2, 0.1); // Same color as the seat
	glPushMatrix();
	glTranslated(0.05, 0, -0.05); // Position another leg
	glScaled(0.02, 0.3, 0.02); // Define the leg size
	glutSolidCube(1);
	glPopMatrix();

	// Leg 4 of the chair (a thin, tall cube)
	glColor3f(0.4, 0.2, 0.1); // Same color as the seat
	glPushMatrix();
	glTranslated(-0.05, 0, -0.05); // Position another leg
	glScaled(0.02, 0.3, 0.02); // Define the leg size
	glutSolidCube(1);
	glPopMatrix();
}

void drawSeesaw() {
	// Seesaw board (a long, flat cube)
	glColor3f(0.7, 0.5, 0.3); // Brown color for the board
	glPushMatrix();
	glTranslated(0, 0.1, 0);
	glRotated(seesawAnimationParameter, 0, 0, 1); // Rotate around the z-axis
	glScaled(0.3, 0.02, 0.05); // Board
	glutSolidCube(1);
	glPopMatrix();

	// Seesaw stand 1 (a shorter, thin cube)
	glColor3f(0.7, 0.5, 0.3); // Same color as the board
	glPushMatrix();
	glTranslated(-0.02, 0, 0);
	glScaled(0.02, 0.2, 0.02); // Stand 1
	glutSolidCube(1);
	glPopMatrix();

	// Seesaw stand 2 (a shorter, thin cube)
	glColor3f(0.7, 0.5, 0.3); // Same color as the board
	glPushMatrix();
	glTranslated(0.02, 0, 0);
	glScaled(0.02, 0.2, 0.02); // Stand 2
	glutSolidCube(1);
	glPopMatrix();
}


void drawWizardTower() {
	// Base of the fountain (a wider, flat cube)
	glColor3f(0.3, 0.4, 1); // Gray color for the base
	glPushMatrix();
	glTranslated(0, 0.1, 0);
	glScaled(0.1, 0.02, 0.1);
	glutSolidCube(1);
	glPopMatrix();

	// Central column (a taller, thin cube)
	glColor3f(0.3, 0.4, 1); // Same color as the base
	glPushMatrix();
	glTranslated(0, 0.3, 0); // Position the column on the base
	glScaled(0.05, 0.6, 0.05); // Define the column's size
	glutSolidCube(1);
	glPopMatrix();

	// Middle platform of the fountain (a wide, flat cube)
	glColor3f(0.3, 0.4, 1); // Same color as the base
	glPushMatrix();
	glTranslated(0, 0.5, 0); // Position the platform on the column
	glScaled(0.1, 0.02, 0.1);
	glutSolidCube(1);
	glPopMatrix();

	// Upper column (a shorter, thin cube)
	glColor3f(0.3, 0.4, 1); // Same color as the base
	glPushMatrix();
	glTranslated(0, 0.6, 0); // Position the upper column on the platform
	glScaled(0.03, 0.3, 0.03);
	glutSolidCube(1);
	glPopMatrix();

	// Decorative top of the fountain (a smaller, flattened cube)
	glColor3f(0.3, 0.4, 1); // Same color as the base
	glPushMatrix();
	glTranslated(0, 0.7, 0); // Position the top on the upper column
	glScaled(0.07, 0.02, 0.07);
	glutSolidCube(1);
	glPopMatrix();
}

void drawCandyShop() {
	glRotatef(90, 0, 1, 0);

	// Shop structure (a tall, thin cube)
	glColor3f(0.8, 0.6, 0.4); // Brown color for the shop
	glPushMatrix();
	glTranslated(0, 0.3, 0);
	glScaled(0.1, 0.6 * candyShopBuildingScale, 0.08); // Shop building
	glutSolidCube(1);
	glPopMatrix();

	// Signboard of the shop (a flat, rectangular cube)
	// Signboard of the shop (a flat, rectangular cube)
	glColor3f(0.5, 0.5, 0.5); // Gray color for the signboard
	glPushMatrix();
	glTranslated(0, 0.4, 0.04);
	glScaled(0.08, 0.02 * candyShopBuildingScale, 0.001); // Signboard
	glutSolidCube(1);
	glPopMatrix();

	// Door of the shop (a flat, rectangular cube)
	glColor3f(0.6, 0.3, 0.1); // Brown color for the door
	glPushMatrix();
	glTranslated(0, 0.1, 0.04);
	glScaled(0.05, 0.2 * candyShopDoorScale, 0.001); // Door
	glutSolidCube(1);
	glPopMatrix();
}


void drawMerryGoRound() {
	// Base pole (a cuboid)
	glColor3f(0.4, 0, 0); // Gray color for the pole
	glPushMatrix();
	glScaled(0.06, 1.0, 0.06); // Adjust the scale to form the main pole
	glutSolidCube(1); // Main pole
	glPopMatrix();

	// Top platform (a flat, rectangular cuboid)
	glColor3f(0.4, 0, 0); // Light gray color for the top
	glPushMatrix();
	glTranslated(0, 0.5, 0);
	glScaled(0.5, 0.05, 0.5); // Top platform size
	glutSolidCube(1); // Top platform
	glPopMatrix();

	// Decoration (four small spheres)
	glColor3f(0.8, 0.2, 0.2); // Red color for the decoration
	for (int i = 0; i < 4; ++i) {
		glPushMatrix();
		glRotated(i * 90 + sphereRotationAngle, 0, 1, 0); // Rotate around the y-axis
		glTranslated(0.25, 0.25, 0);
		glutSolidSphere(0.05, 10, 10); // Decoration spheres
		glPopMatrix();
	}
}

void drawHuman() {
	glPushMatrix();
	glTranslatef(playerX, 0.0f, playerZ);
	glRotatef(rotationAngle, 0, 1, 0);
	// Head (a sphere)
	glColor3f(1.0, 0.8, 0.6); // Skin color for the head
	glPushMatrix();
	glTranslated(0, 1.55, 0);
	glutSolidSphere(0.08, 5, 5); // Head
	glPopMatrix();

	// Body (a cuboid)
	glColor3f(0.0, 0.4, 1.0); // Blue color for the body
	glPushMatrix();
	glTranslated(0, 1.35, 0);
	glScaled(0.09, 0.10, 0.02); // Body size
	glutSolidCube(1); // Body
	glPopMatrix();

	// Limbs - Arms and Legs (cuboids)
	glColor3f(0.8, 0.6, 0.4); // Brown color for the limbs
	// Left arm
	glPushMatrix();
	glTranslated(0.08, 1.4, 0);
	glScaled(0.025, 0.075, 0.02); // Left arm size
	glutSolidCube(1); // Left arm
	glPopMatrix();

	// Right arm
	glPushMatrix();
	glTranslated(-0.08, 1.4, 0);
	glScaled(0.025, 0.075, 0.02); // Right arm size
	glutSolidCube(1); // Right arm
	glPopMatrix();

	// Left leg
	glPushMatrix();
	glTranslated(0.03, 1.2, 0);
	glScaled(0.035, 0.1, 0.02); // Left leg size
	glutSolidCube(1); // Left leg
	glPopMatrix();

	// Right leg
	glPushMatrix();
	glTranslated(-0.03, 1.2, 0);
	glScaled(0.035, 0.1, 0.02); // Right leg size
	glutSolidCube(1); // Right leg
	glPopMatrix();

	glPopMatrix();
}


void drawFerrisWheel() {
	// Ferris Wheel support structure
	glColor3f(0.5, 0.5, 0.5);
	glPushMatrix();
	glTranslated(0, -0.3, 0);
	glScaled(0.04, 0.6, 0.04); // Adjusted scaling for the support structure
	glutSolidCube(1);
	glPopMatrix();

	// Ferris Wheel main body
	glColor3f(0.7, 0.7, 0.7);
	glPushMatrix();
	glTranslated(0, 0.3, 0);
	glScaled(0.16, 0.08, 0.04); // Adjusted scaling for the main body
	glutSolidCube(1);
	glPopMatrix();

	// Ferris Wheel cabins
	glColor3f(0.4, 0.4, 0.9);
	for (int i = 0; i < 8; ++i) {
		glPushMatrix();
		glRotated(i * 45 + ferrisWheelRotationAngle, 0, 0, 1);
		glTranslated(0.2, 0.3, 0);
		glScaled(0.14, 0.2, 0.1); // Adjusted scaling for the cabins
		glutSolidCube(1);
		glPopMatrix();
	}
}



void setupLights() {
	GLfloat ambient[] = { 0.7f, 0.7f, 0.7, 1.0f };
	GLfloat diffuse[] = { 0.6f, 0.6f, 0.6, 1.0f };
	GLfloat specular[] = { 1.0f, 1.0f, 1.0, 1.0f };
	GLfloat shininess[] = { 50 };
	glMaterialfv(GL_FRONT_AND_BACK, GL_AMBIENT, ambient);
	glMaterialfv(GL_FRONT, GL_DIFFUSE, diffuse);
	glMaterialfv(GL_FRONT, GL_SPECULAR, specular);
	glMaterialfv(GL_FRONT, GL_SHININESS, shininess);

	GLfloat lightIntensity[] = { 0.7f, 0.7f, 1, 1.0f };
	GLfloat lightPosition[] = { -7.0f, 6.0f, 3.0f, 0.0f };
	glLightfv(GL_LIGHT0, GL_POSITION, lightIntensity);
	glLightfv(GL_LIGHT0, GL_DIFFUSE, lightIntensity);
}
void setupCamera() {
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluPerspective(60, 640 / 480, 0.001, 100);

	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
	camera.look();
}


void drawText(float x, float y, float z, void* font, const char* string) {
	glMatrixMode(GL_PROJECTION);
	glPushMatrix();
	glLoadIdentity();
	gluOrtho2D(0.0, 640, 0.0, 480);

	glMatrixMode(GL_MODELVIEW);
	glPushMatrix();
	glLoadIdentity();
	glRasterPos3f(x, y, z);

	int len = (int)strlen(string);
	for (int i = 0; i < len; i++) {
		glutBitmapCharacter(font, string[i]);
	}

	glMatrixMode(GL_PROJECTION);
	glPopMatrix();

	glMatrixMode(GL_MODELVIEW);
	glPopMatrix();
}

void Display() {
	setupCamera();
	setupLights();

	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	//glLoadIdentity();

	glPushMatrix();
	glLoadIdentity();
	glTranslatef(glutGet(GLUT_WINDOW_WIDTH) - 100, glutGet(GLUT_WINDOW_HEIGHT) - 20, 0);
	char timeString[20];
	snprintf(timeString, sizeof(timeString), "Time: %d", remainingTime);
	drawText(0, 0,0, GLUT_BITMAP_TIMES_ROMAN_24, timeString);
	glPopMatrix();

	// Ground
	glColor3f(0.3, 0.7, 0.3); // Green color for the ground
	glBegin(GL_QUADS);
	glVertex3f(-5, 0, -5);  // Define vertices of the square
	glVertex3f(-5, 0, 5);
	glVertex3f(5, 0, 5);
	glVertex3f(5, 0, -5);
	glEnd();

	// Walls
    glColor3f(0.5, 0.5, 0.5); // Gray color for the walls
    // Draw the walls at the borders
    drawWall(0.02); // Front wall
    glPushMatrix();
    glRotated(90, 0, 0, 1.0);
    drawWall(0.02); // Side wall
    glPopMatrix();
    glPushMatrix();
    glRotated(-90, 1.0, 0.0, 0.0);
    drawWall(0.02); // Side wall
    glPopMatrix();

	glPushMatrix();
	glTranslated(0.3, 0, 0.2); 
	drawBench(); 
	glPopMatrix();
	glPushMatrix();
	glTranslated(0.5, 0, 0.2); 
	drawBench(); 
	glPopMatrix();

	glPushMatrix();
	glTranslated(1.2, 0, -0.8); 
	drawDesk();
	glPopMatrix();

	glPushMatrix();
	glTranslated(1.4, -1.12, 0.3);
	drawHuman();
	glPopMatrix();

	glPushMatrix();
    glTranslated(1, 0, 0.2); 
    drawChair(); 
    glPopMatrix();

	glPushMatrix();
	glTranslated(0.2, 0, 0.5); // Position the fountain in the scene
	drawWizardTower(); // Draw the water fountain
	glPopMatrix();

	glPushMatrix();
	glTranslated(1.2, 0, 1.2); // Adjust position to place the Swing Ride in the scene
	drawMerryGoRound(); // Draw the Swing Ride
	glPopMatrix();

	glPushMatrix();
	glTranslated(0.9, 0, 0.5); 
	drawSeesaw(); 
	glPopMatrix();

	glPushMatrix();
	glTranslated(0.5, 0.5, 1);
	drawFerrisWheel();
	glPopMatrix();

	glPushMatrix();
	glTranslated(0.2, 0, 1.3); 
	drawCandyShop();
	glPopMatrix();


	if (playerX==-1.2 && playerZ == 1.0) {
		candyShopX = 100.0f;
		candyShopZ = 100.0f;
		win = 1;
	}
	if (win == 1) {
		glColor3f(0.0, 1.0, 0.0); // Green color for win
		drawText(270, 240, 0.0, GLUT_BITMAP_TIMES_ROMAN_24, "You Win");
	}
	if (win == -1) {
		glColor3f(1.0, 0.0, 0.0); // Red color for lost
		drawText(270, 240, 1.0, GLUT_BITMAP_TIMES_ROMAN_24, "You Lost");
	}

	glFlush();
	//glutSwapBuffers();
}

void Keyboard(unsigned char key, int x, int y) {
	float d = 0.01;
	float moveDistance = 0.1f;
	float newRotationAngle = 0.0f;
	if (win == 0) {
		switch (key) {
		case 'w':
			camera.moveY(d);
			break;
		case 's':
			camera.moveY(-d);
			break;
		case 'a':
			camera.moveX(d);
			break;
		case 'd':
			camera.moveX(-d);
			break;
		case 'q':
			camera.moveZ(d);
			break;
		case 'e':
			camera.moveZ(-d);
			break;
		case 'u':
			if (playerZ + moveDistance <= wallScale / 1.6) {
				playerZ += moveDistance;
				newRotationAngle = 180.0f; // Angle for moving down
			}
			break;
		case 'j':
			if (playerZ - moveDistance >= -wallScale / 8.0) {
				playerZ -= moveDistance;
				newRotationAngle = 0.0f; // Angle for moving up
			}
			break;
		case 'h':
			if (playerX - moveDistance >= -wallScale / 1.5) {
				playerX -= moveDistance;
				newRotationAngle = 90.0f; // Angle for moving left
			}
			break;
		case 'k':
			if (playerX + moveDistance <= wallScale / 11.0) {
				playerX += moveDistance;
				newRotationAngle = -90.0f; // Angle for moving right
			}
			break;

		case GLUT_KEY_ESCAPE:
			exit(EXIT_SUCCESS);

		case '1':
			camera.eye.x = 1.0445;
			camera.eye.y = 2.10832;
			camera.eye.z = 1.0445;
			camera.center.x = 0.910585;
			camera.center.y = 1.12642;
			camera.center.z = 0.910585;
			break;

		case '2':
			camera.eye.x = 2.8759;
			camera.eye.y = 0.453798;
			camera.eye.z = 0.659243;
			camera.center.x = 1.87749;
			camera.center.y = 0.508784;
			camera.center.z = 0.671286;
			break;
		case '3':
			camera.eye.x = 0.658104;
			camera.eye.y = 0.616104;
			camera.eye.z = 2.7959;
			camera.center.x = 0.710845;
			camera.center.y = 0.63961;
			camera.center.z = 1.79756;
			break;
		case 'p':
			animateBench = true;
			animateDesk = true;
			animateSeesaw = true;
			animateSphere = true;
			animateFerrisWheel = true;
			break;
		case 'l':
			animateBench = false;
			animateDesk = false;
			animateSeesaw = false;
			animateSphere = false;
			animateFerrisWheel = false;
			break;
		
		}

		

		if (newRotationAngle != 0.0f) {
			rotationAngle = newRotationAngle;
			glutPostRedisplay();
		}
		//Set the goal collision
		std::cout << playerX << ", "<< playerZ << std::endl;

		//Find the camera views
		//std::cout << camera.eye.x << ", " << camera.eye.y << ", " << camera.eye.z  << std::endl;
		//std::cout << camera.center.x << ", " << camera.center.y << ", " << camera.center.z << std::endl;
		glutPostRedisplay();
	}
}

void Special(int key, int x, int y) {
	float a = 1.0;
	

	switch (key) {
	case GLUT_KEY_UP:
		camera.rotateX(a);
		break;
	case GLUT_KEY_DOWN:
		camera.rotateX(-a);
		break;
	case GLUT_KEY_LEFT:
		camera.rotateY(a);
		break;
	case GLUT_KEY_RIGHT:
		camera.rotateY(-a);
		break;
	}

	glutPostRedisplay();
}

void main(int argc, char** argv) {
	glutInit(&argc, argv);

	glutInitWindowSize(640, 480);
	glutInitWindowPosition(50, 50);
	glutTimerFunc(1000, Timer, 0);

	glutCreateWindow("Lab 6");
	glutDisplayFunc(Display);
	glutKeyboardFunc(Keyboard);
	glutSpecialFunc(Special);

	glutInitDisplayMode(GLUT_SINGLE | GLUT_RGB | GLUT_DEPTH);
	glClearColor(1.0f, 1.0f, 1.0f, 0.0f);

	glEnable(GL_DEPTH_TEST);
	glEnable(GL_LIGHTING);
	glEnable(GL_LIGHT0);
	glEnable(GL_NORMALIZE);
	glEnable(GL_COLOR_MATERIAL);

	glShadeModel(GL_SMOOTH);
	glutIdleFunc(animateObjects);


	glutMainLoop();
}
